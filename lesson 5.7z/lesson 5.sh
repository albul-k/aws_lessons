C:\Users\konst>ssh -i aws_test.pem ubuntu@3.18.221.227
The authenticity of host '3.18.221.227 (3.18.221.227)' can't be established.
ECDSA key fingerprint is SHA256:Yl0s/HXn68CObmc4a91euQcAzeiIYifxzeEjL9Rkcts.
Are you sure you want to continue connecting (yes/no)? yes
Warning: Permanently added '3.18.221.227' (ECDSA) to the list of known hosts.
Welcome to Ubuntu 18.04.4 LTS (GNU/Linux 4.15.0-1065-aws x86_64)Welcome to Ubuntu 18.04.4 LTS (GNU/Linux 4.15.0-1065-aws x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage

  System information as of Sun May 31 19:38:09 UTC 2020

  System load:  0.0               Processes:           86
  Usage of /:   13.7% of 7.69GB   Users logged in:     0
  Memory usage: 14%               IP address for eth0: 172.31.32.215
  Swap usage:   0%

0 packages can be updated.
0 updates are security updates.



The programs included with the Ubuntu system are free software;
the exact distribution terms for each program are described in the
individual files in /usr/share/doc/*/copyright.

Ubuntu comes with ABSOLUTELY NO WARRANTY, to the extent permitted by
applicable law.

To run a command as administrator (user "root"), use "sudo <command>".
See "man sudo_root" for details.

# step 1: call htop
ubuntu@ip-172-31-32-215:~$ htop

# step 2: find all *.py files
ubuntu@ip-172-31-32-215:~$ echo >> prog_1.py
ubuntu@ip-172-31-32-215:~$ echo >> prog_2.py
ubuntu@ip-172-31-32-215:~$ echo >> prog_3.py
ubuntu@ip-172-31-32-215:~$ vim prog_1.py
ubuntu@ip-172-31-32-215:~$ cat prog_1.py
from time import sleep

for i in range(1,100):
    print(i)
    sleep(1)
ubuntu@ip-172-31-32-215:~$ find *.py
prog_1.py
prog_2.py
prog_3.py

# step 3: call htop
ubuntu@ip-172-31-32-215:~$ python3 prog_1.py > log.txt &
[1] 1663
ubuntu@ip-172-31-32-215:~$ htop

# step 4: sorted root processes by memory usege (without 3 line's limit...)
ubuntu@ip-172-31-32-215:~$ htop -u root -s PERCENT_MEM