# login to first instance
C:\Users\konst>ssh -i aws_test.pem ubuntu@18.188.174.164
Welcome to Ubuntu 18.04.4 LTS (GNU/Linux 4.15.0-1065-aws x86_64)

 * Documentation:  https://help.ubuntu.comWelcome to Ubuntu 18.04.4 LTS (GNU/Linux 4.15.0-1065-aws x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage

  System information as of Wed Jun  3 19:15:44 UTC 2020

  System load:  0.17              Processes:           90
  Usage of /:   13.9% of 7.69GB   Users logged in:     0
  Memory usage: 14%               IP address for eth0: 172.31.46.225
  Swap usage:   0%


0 packages can be updated.
0 updates are security updates.


Last login: Wed Jun  3 19:10:11 2020 from 193.233.154.128

# step 1-1: install zip
ubuntu@ip-172-31-46-225:~$ sudo apt install zip
Reading package lists... Done
Building dependency tree
Reading state information... Done
The following NEW packages will be installed:
  zip
0 upgraded, 1 newly installed, 0 to remove and 0 not upgraded.
Need to get 167 kB of archives.
After this operation, 638 kB of additional disk space will be used.
Get:1 http://us-east-2.ec2.archive.ubuntu.com/ubuntu bionic/main amd64 zip amd64 3.0-11build1 [167 kB]
Fetched 167 kB in 0s (11.6 MB/s)
Selecting previously unselected package zip.
(Reading database ... 56606 files and directories currently installed.)
Preparing to unpack .../zip_3.0-11build1_amd64.deb ...
Unpacking zip (3.0-11build1) ...
Setting up zip (3.0-11build1) ...
Processing triggers for man-db (2.8.3-2ubuntu0.1) ...
# step 1-2: see step_1-2.png

# step 2-1: see step_2-1.png
# step 2-2: login to second instance
C:\Users\konst>ssh -i aws_test.pem ubuntu@3.15.46.5
Welcome to Ubuntu 18.04.4 LTS (GNU/Linux 4.15.0-1065-aws x86_64)
Welcome to Ubuntu 18.04.4 LTS (GNU/Linux 4.15.0-1065-aws x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage

  System information as of Wed Jun  3 19:32:45 UTC 2020

  System load:  0.01              Processes:           88
  Usage of /:   13.9% of 7.69GB   Users logged in:     0
  Memory usage: 15%               IP address for eth0: 172.31.39.37
  Swap usage:   0%


0 packages can be updated.
0 updates are security updates.


Last login: Wed Jun  3 19:31:25 2020 from 193.233.154.128
ubuntu@ip-172-31-39-37:~$ apt list
# ....
# step 2-3: zip installed (see step_2-2.png)
ubuntu@ip-172-31-39-37:~$ exit

# step 3-1: create new volume (see step_3-1.png)
# step 3-2: login to first instance
C:\Users\konst>ssh -i aws_test.pem ubuntu@18.188.174.164
Welcome to Ubuntu 18.04.4 LTS (GNU/Linux 4.15.0-1065-aws x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage
Welcome to Ubuntu 18.04.4 LTS (GNU/Linux 4.15.0-1065-aws x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage

  System information as of Wed Jun  3 19:48:17 UTC 2020

  System load:  0.0               Processes:           86
  Usage of /:   13.9% of 7.69GB   Users logged in:     0
  Memory usage: 14%               IP address for eth0: 172.31.46.225
  Swap usage:   0%


0 packages can be updated.
0 updates are security updates.


Last login: Wed Jun  3 19:15:45 2020 from 193.233.154.128

# step 3-3
ubuntu@ip-172-31-46-225:~$ lsblk
NAME    MAJ:MIN RM  SIZE RO TYPE MOUNTPOINT
loop0     7:0    0   18M  1 loop /snap/amazon-ssm-agent/1566
loop1     7:1    0 93.8M  1 loop /snap/core/8935
xvda    202:0    0    8G  0 disk
└─xvda1 202:1    0    8G  0 part /
xvdf    202:80   0    1G  0 disk
ubuntu@ip-172-31-46-225:~$ sudo file -s /dev/xvdf
/dev/xvdf: data

# step 3-4: format volume
ubuntu@ip-172-31-46-225:~$ sudo mkfs -t xfs /dev/xvdf
meta-data=/dev/xvdf              isize=512    agcount=4, agsize=65536 blks
         =                       sectsz=512   attr=2, projid32bit=1
         =                       crc=1        finobt=1, sparse=0, rmapbt=0, reflink=0
data     =                       bsize=4096   blocks=262144, imaxpct=25
         =                       sunit=0      swidth=0 blks
naming   =version 2              bsize=4096   ascii-ci=0 ftype=1
log      =internal log           bsize=4096   blocks=2560, version=2
         =                       sectsz=512   sunit=0 blks, lazy-count=1
realtime =none                   extsz=4096   blocks=0, rtextents=0

# step 3-5: check filesystem
ubuntu@ip-172-31-46-225:~$ sudo file -s /dev/xvdf
/dev/xvdf: SGI XFS filesystem data (blksz 4096, inosz 512, v2 dirs)
ubuntu@ip-172-31-46-225:~$ sudo mkdir /data
ubuntu@ip-172-31-46-225:~$ sudo cp /etc/fstab /etc/fstab.orig

# step 3-6: mount volume
ubuntu@ip-172-31-46-225:~$ sudo mount /dev/xvdf /data
ubuntu@ip-172-31-46-225:~$ lsblk
NAME    MAJ:MIN RM  SIZE RO TYPE MOUNTPOINT
loop0     7:0    0   18M  1 loop /snap/amazon-ssm-agent/1566
loop1     7:1    0 93.8M  1 loop /snap/core/8935
xvda    202:0    0    8G  0 disk
└─xvda1 202:1    0    8G  0 part /
xvdf    202:80   0    1G  0 disk /data
ubuntu@ip-172-31-46-225:~$ blkid
/dev/xvda1: LABEL="cloudimg-rootfs" UUID="6156ec80-9446-4eb1-95e0-9ae6b7a46187" TYPE="ext4" PARTUUID="fe3a9f65-01"
/dev/xvdf: UUID="263b0a10-6894-4665-8380-a6b233d2e10b" TYPE="xfs"
ubuntu@ip-172-31-46-225:~$ sudo nano /etc/fstab

# step 3-7: fstab (see step_3-7.png)

ubuntu@ip-172-31-46-225:~$ sudo umount /data
ubuntu@ip-172-31-46-225:~$ sudo mount -a
ubuntu@ip-172-31-46-225:~$ sudo chmod o+w /data

# step 3-8: create test.txt with "Hello, world!"
ubuntu@ip-172-31-46-225:~$ cd /data
ubuntu@ip-172-31-46-225:/data$ vim test.txt
ubuntu@ip-172-31-46-225:/data$ cat test.txt
Hello, World!
ubuntu@ip-172-31-46-225:/data$ cd
ubuntu@ip-172-31-46-225:~$ sudo umount /data

# step 3-9: mount volume to second instance

# step 3-10: login
C:\Users\konst>ssh -i aws_test.pem ubuntu@3.15.46.5
Welcome to Ubuntu 18.04.4 LTS (GNU/Linux 4.15.0-1065-aws x86_64)

 * Documentation:  https://help.ubuntu.comWelcome to Ubuntu 18.04.4 LTS (GNU/Linux 4.15.0-1065-aws x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage

  System information as of Wed Jun  3 20:54:56 UTC 2020

  System load:  0.36              Processes:           90
  Usage of /:   13.9% of 7.69GB   Users logged in:     0
  Memory usage: 14%               IP address for eth0: 172.31.39.37
  Swap usage:   0%


0 packages can be updated.
0 updates are security updates.


Last login: Wed Jun  3 20:51:11 2020 from 193.233.154.128

# step 3-10: check test.txt
ubuntu@ip-172-31-39-37:~$ sudo mount /dev/xvdf /data
ubuntu@ip-172-31-39-37:/data$ ls
test.txt
ubuntu@ip-172-31-39-37:/data$ cat test.txt
Hello, World!
ubuntu@ip-172-31-39-37:/data$